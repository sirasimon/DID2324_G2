#ifndef CustomTimer_h
#define CustomTimer_h
#include "Arduino.h"
class CustomTimer {
  public:
    CustomTimer(unsigned long duration);
    bool checkAndUpdate();
  private:
    unsigned long duration;
    unsigned long timestamp; 
};
#endif
  
