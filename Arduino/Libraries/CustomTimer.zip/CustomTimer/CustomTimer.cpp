#include "Arduino.h"
#include "CustomTimer.h"

CustomTimer::CustomTimer(unsigned long duration) {
  this -> duration = duration;
  timestamp = millis() + duration;
}

bool CustomTimer::checkAndUpdate() {
  if (millis() >= timestamp) {
    timestamp = millis() + duration;
    return true;  
  }
  return false;
}
